let jobModel=(function(){
  //获取元素
  $tableBox = $('.tableBox'),
    $tbody = $tableBox.children('tbody');

  //render获取元素渲染
  let render =function(){
    
  };


  return {
    init(){

    }
  }
})();

jobModel.init();