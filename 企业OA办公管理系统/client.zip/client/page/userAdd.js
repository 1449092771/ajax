let userAddModel = (function () {
  //=>获取元素
  let $userName=$('.username'),
      $sexRadio=$('.sexRadio'), //性别的你级元素
      $selectBox=$('.selectBox'),
      $useremail=$('.useremail'),
      $userphone=$('.userphone'),
      $textarea=$('textarea');



  //=>获取部门
  let departmentMeg =function(){
    let str = `<option value="0">全部</option>`,
        departmentMsg=JSON.parse(localStorage.getItem('departmentMsg'));
				departmentMsg.forEach(item => {
					str += `<option value="${item.id}">${item.name}</option>`;
				});
				$selectBox.html(str);
  }

  //=>获取职务信息  /job/list
  let selectJob = function () {
		return axios.get('/job/list').then(result => {
			if (parseInt(result.code) === 0) {
				localStorage.setItem('departmentMsg',JSON.stringify(result.data));
				let str = `<option value="0">全部</option>`;
				result.data.forEach(item => {
					str += `<option value="${item.id}">${item.name}</option>`;
				});
				$selectBox.html(str);
			}
		});
	};





  return {
		init() {
      departmentMeg(); //部门信息
      selectJob();  //职务信息
		}
	}

})();

userAddModel.init();